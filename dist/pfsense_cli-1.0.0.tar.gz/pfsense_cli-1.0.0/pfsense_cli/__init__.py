"""
pfSense Configuration Management CLI Tool

A professional automation tool for managing pfSense configurations
including client management, network operations, and VPN setup.
"""

__version__ = "1.0.0"
__author__ = "pfSense CLI Tool"
__description__ = "Professional pfSense automation and configuration management"